package com.acn.app;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }

	public static String getHelloWorld() {

		return "Hello World";

	}

	public static String getHelloWorld2() {

		return "Hello World 2";

	}
}
